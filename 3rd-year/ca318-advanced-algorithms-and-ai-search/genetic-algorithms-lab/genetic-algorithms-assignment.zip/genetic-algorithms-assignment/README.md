To output values from the genetic algorithm, run:
`python3 draw_graph.py`

To show the relationship between cost and iterations drawn on a graph, run:
`python3 plot.py`
